# NyayaSetu — Your AI Consumer Rights Assistant

*From consumer problem to legal action.*

NyayaSetu helps an ordinary person in India who has a problem with something they bought online — a refund that never came, a damaged or defective product, an order marked "delivered" that never arrived, a misleading listing, or a wrong charge. It turns their story (English or Hindi) into a structured case file, explains where they stand using **verified official sources only**, drafts four ready-to-edit documents, and gives a practical action plan.

Built for the Kuku AI Generalist Assignment, **Problem 2: Build an AI Lawyer**.

> NyayaSetu is an AI-assisted legal information and document-preparation tool. It does not replace a qualified advocate or constitute a lawyer-client relationship. Legal outcomes depend on facts and applicable law. Verify important legal decisions with a qualified professional.

---

## 1. Quick start (about 2 minutes)

Requirements: **Python 3.11 or newer** (Streamlit 1.67 needs 3.11+; tested from a clean install on 3.11 and 3.13). No API key, no paid service, no internet access needed at run time.

**macOS / Linux**
```bash
cd nyayasetu
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

**Windows (PowerShell)**
```powershell
cd nyayasetu
py -3.11 -m venv .venv          # or: python -m venv .venv  (if python is 3.11+)
.venv\Scripts\Activate.ps1      # if blocked: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
pip install -r requirements.txt
streamlit run app.py
```

The app opens at http://localhost:8501. It starts in **Demo mode** (shown in the sidebar): every response is produced by deterministic rules and the verified knowledge base; no AI model is called.

Run the tests (with the virtual environment active and `pip install -r requirements.txt` done):
```bash
python tests/run_tests.py          # 7 scenarios + claimed-amount, hallucination, retrieval and privacy tests -> outputs/
python tests/test_llm_provider.py  # 22 optional-LLM checks (fake client + real SDK against a local mock; no key needed)
python tests/test_app_journey.py   # drives the Streamlit UI end-to-end (no browser needed)
```
Expected with the full requirements installed: `RESULT: all gated checks passed for 7/7 scenarios`, `22/22 LLM-integration checks executed and passed`, `ALL APP JOURNEY CHECKS PASSED: 23/23 steps executed`.

| Script | Needs | If the package is missing |
|---|---|---|
| `run_tests.py` | `fpdf2` (+ `uharfbuzz` for correctly shaped Hindi PDFs) | Without `uharfbuzz`: runs, prints a warning that Hindi PDFs are unshaped. Exits 1 if any check fails |
| `test_llm_provider.py` | 16 checks: nothing extra · 6 checks: `anthropic` | The 6 SDK checks are listed as `NOT RUN` (e.g. "16/16 … executed and passed; 6 of 22 NOT RUN"); they are never counted as passed |
| `test_app_journey.py` | `streamlit` | Prints `NOT RUN` and exits with code 2 |

## 2. Environment variables (all optional)

Copy `.env.example` to `.env`. With nothing set, the app runs in demo mode.

| Variable | Purpose |
|---|---|
| `NYAYASETU_LLM_PROVIDER` | `demo` (default), `anthropic`, or `openai_compatible` |
| `ANTHROPIC_API_KEY` | Anthropic API key from the Claude Console (a Claude Pro chat subscription does not include API access) |
| `NYAYASETU_ANTHROPIC_MODEL` | Model ID, default `claude-sonnet-5-5` (listed as current on Anthropic's models page, checked 8 Nov 2026). Any current ID works, e.g. `claude-haiku-5-5` |
| `NYAYASETU_ANTHROPIC_EFFORT`, `NYAYASETU_ANTHROPIC_MIN_MAX_TOKENS` | Default `low` and `4096`. Effort is sent as `output_config.effort` (empty = not sent); the token floor exists because `max_tokens` covers adaptive thinking plus text |
| `NYAYASETU_OPENAI_BASE_URL`, `NYAYASETU_OPENAI_API_KEY`, `NYAYASETU_OPENAI_MODEL`, `NYAYASETU_OPENAI_TEMPERATURE` | Any OpenAI-compatible endpoint (OpenAI, Groq, Together, local Ollama…). Temperature is sent only if set |
| `NYAYASETU_LLM_TIMEOUT` | Seconds per live call (default 60) |
| `NYAYASETU_REFERENCE_DATE` | Pin "today" (YYYY-MM-DD) so "three weeks ago" resolves reproducibly in demos/tests |

If a provider is selected but its key is missing, or a call fails, the app falls back to the rule-based output and says so on screen. Keys are never hard-coded.

**Using a real Anthropic key**
```bash
export NYAYASETU_LLM_PROVIDER=anthropic          # Windows PowerShell: $env:NYAYASETU_LLM_PROVIDER="anthropic"
export ANTHROPIC_API_KEY=sk-ant-...              # your own key; never commit it
python -m core.llm_provider                      # sends one tiny test request and prints OK or the exact API error
streamlit run app.py
```
Notes from Anthropic's Sonnet 5.5 migration guide that the provider follows: `temperature`/`top_p`/`top_k` return a 400 error on current models, so they are never sent; responses may start with thinking blocks, so only `text` blocks are read.

**What is AI and what is not.** The sidebar shows *Demo mode* or *Live AI mode · provider · model*. On the rights page the summary is labelled *Rule-based explanation* or *AI-written (model) and checked against the verified sources*; AI text that fails validation is discarded and the rule-based text is shown with the reason. Facts filled by a model are marked "(AI)" in the intake panel and listed as "suggested by AI" on the case page. **Complaint drafts are always templates — no AI-written text in any mode** (labelled on the complaint page).

## 3. What the app does (the 5-step workflow)

| Step | Page | What happens |
|---|---|---|
| 1 | **Start a Legal Case** | User describes the problem in their own words. Rules extract amount, dates ("three weeks ago" → a date), platform, seller, order ID, ticket number, evidence and steps taken, and classify the dispute. NyayaSetu then asks **only the questions still missing for that dispute type**, one at a time; every question can be skipped. If a refund is wanted, it asks **how much is being claimed** (full price, a partial amount, or only the excess on a wrong charge) and re-asks once if the answer is unclear — it never assumes the full price. Aadhaar/PAN/card numbers/OTPs typed by mistake are masked. |
| 2 | **My Case Summary** | Editable case file: nature of dispute, parties, timeline, financial loss, what was expected vs what happened, steps taken, evidence, desired resolution, **refund amount being claimed**, and a **missing-information list** explaining why each item matters. Every field records where it came from (rules / your answer / your correction / AI). Download or restore as JSON. |
| 3 | **Understand My Rights** | Issue cards, each labelled as *What the law requires*, *Possible legal argument*, *Procedure*, *Possible remedy* or *Notice*, with a confidence label. Each card has: what the law says (plain language + official excerpt), how it may apply to these facts, evidence you have/still need, what to do, and the official source (URL, authority, date checked, verification status). Plus uncertainties, "when to speak to a lawyer", and a question box that retrieves verified passages. |
| 4 | **Generate Complaint** | A. email to the seller · B. formal complaint to the platform's grievance officer · C. National Consumer Helpline grievance · D. Consumer Commission preparation draft — in English or Hindi. The relief asks for exactly the confirmed refund amount (or shows `[MISSING: amount you are claiming — you paid ₹X]`). Editable; downloads as TXT and PDF; `[MISSING: …]` and `[ADD: …]` fields are highlighted; every draft is labelled as an unfiled draft; edits are re-validated live (adding a fake section number triggers a warning). |
| 5 | **Recommended Next Steps** | Preserve evidence → written complaint/grievance officer → keep references → (category-specific steps) → National Consumer Helpline → Consumer Commission via e-Jagriti. Each step: what to do, why it matters, official website, evidence to keep. No invented waiting periods. |

The **Legal Sources & Limitations** page shows the full knowledge base, its verification log, known limitations and how data is handled.

## 4. Architecture

```
            ┌───────────────────────── app.py (Streamlit UI, session-only state) ─────────────────────────┐
user text → │ core/intake.py ──► core/case_builder.py ──► core/rights_analyzer.py ──► core/complaint_generator.py
            │  rules: classify,     structured JSON case,    issue rules keyed to      template drafts (EN/HI)
            │  extract, ask next    timeline, missing info,  category + facts;          facts quoted from user;
            │  relevant question    flags (limitation,       sources from KB only       citations from KB only
            │        │              commercial purpose…)            │                           │
            │        └─(optional) llm_provider: fills gaps          ├── legal_retrieval.py (BM25 + intent boosts over data/legal_sources.json)
            │                                                       ├── legal_validation.py (citation / case-law / other-Act / guarantee checker)
            │                                                       └─(optional) llm_provider: friendlier summary, kept only if validator passes
            │ core/action_planner.py ─► next steps        utils/pdf_generator.py ─► PDF (fpdf2 + HarfBuzz, merged Noto font)
            └──────────────────────────────────────────────────────────────────────────────────────────────┘
```

* `core/pipeline.py` runs the same path for the app and the test harness.
* `core/llm_provider.py` — `DemoProvider` (default), `AnthropicProvider`, `OpenAICompatibleProvider`. Swapping models is one environment variable.
* `data/legal_sources.json` — 30 hand-checked entries (27 verified against official text, 3 dated notices; re-verified 8 Nov 2026) (Consumer Protection Act 2019 sections, E-Commerce Rules 2020, Jurisdiction Rules 2021, fee rule as amended 2023, NCH, e-Jagriti, plus dated notices for the E-Commerce Amendment Rules 2026 and the RBI Ombudsman scheme). Each entry: official URL, issuing authority, excerpt, plain-language EN/HI text, verification status and date.

### Where AI is used vs deterministic rules

| Function | Demo mode (default) | With an LLM configured |
|---|---|---|
| Fact extraction | Regex + keyword rules | Rules first; LLM may fill **empty** fields only; order ID / seller / platform accepted only if the string appears in the user's text |
| Dispute classification | Weighted keyword scoring | LLM used only if rules return "unknown" |
| Legal analysis (issue cards) | Deterministic rules + KB | Same — never delegated to the model |
| Plain-language summary / question box | Rule-built text / retrieved passages | LLM writes from retrieved KB entries; output must tag every rule with `[KB:ID]`; rejected (fallback to rules) if it cites anything unverified, cites case law or another Act, or promises an outcome |
| Complaint drafts | Templates | Templates (deliberately: no model-written facts in legal documents) |

**Honest disclosure:** no live LLM API was connected while building and testing this prototype. All saved outputs come from demo mode. The LLM path and its validator were exercised with a scripted fake model (`tests/run_tests.py → hallucination_injection_test.json`), and the Anthropic request was checked with the real `anthropic` SDK against a local mock server (`tests/test_llm_provider.py`; these 6 checks run only when the `anthropic` package is installed) — not against the real API. Which tests ran in which environment is listed in `EVALUATION_REPORT.md` §2a.

## 5. How legal hallucinations are prevented

1. **Curated KB, verified against official text** (India Code, Gazette, DoCA, NCH, PIB, Lok Sabha answer), re-verified on 8 Nov 2026 (corrections are logged in the KB and in `EVALUATION_REPORT.md` §4); statuses `verified` / `verified_secondary` (shown only as notices) / `needs_verification` (never shown as law).
2. **Rules choose the law, not a model.** Each issue card references KB IDs; legal text shown is the KB's.
3. **Validator** (`core/legal_validation.py`) extracts every Section/Rule/धारा/नियम, case-law pattern (`X v. Y`, `AIR`, `SCC`, `CPJ`), other named Acts, and `[KB:…]` tags; anything not in the verified KB fails. Runs on every draft (and live on user edits) and on every AI output.
4. **Over-claiming guards in the rules**, e.g. the 30-day unfair-trade-practice clause (Section 2(47)(viii)) is *not* asserted when fewer than 30 days have passed or when the consumer asked for a replacement rather than a refund; product liability is explained as covering harm beyond the product itself.
5. **No guarantees**: outcome-promise language is detected (negation-aware) and blocked.
6. **No invented money claims**: the refund in every draft is the amount the user confirmed, or a `[MISSING]` marker; an automated check enforces this on all 32 test drafts.

## 6. Tests and outputs

| Path | Contents |
|---|---|
| `tests/test_cases.json` | 7 scenarios (5 required + 2 deliberately difficult), scripted answers and expected values |
| `outputs/raw_outputs/TCxx_*/` | Unedited outputs per scenario: `conversation.md`, `case_file.json`, `rights_analysis.json/.md`, `action_plan.json/.md`, `documents/*.txt`, `automated_checks.json` |
| `outputs/raw_outputs/automated_checks.md` | Summary of automated checks, claimed-amount paths, retrieval probes, hallucination-injection and privacy tests |
| `tests/test_llm_provider.py` | 22 optional-LLM checks: request shape, model ID configuration, fallbacks (16, fake client); real SDK against a local mock (6, need the `anthropic` package) |
| `outputs/generated_complaints/` | PDFs of every generated draft (32 files: 7 scenarios × 4 drafts, plus English versions of the Hindi scenario) |
| `EVALUATION_REPORT.md` | Quality evaluation table, manual review findings, errors found and fixed, remaining limitations |
| `docs/NyayaSetu_Kuku_Solution.pdf` | Two-page assignment solution document |
| `docs/sample_complaint_TC01_platform_complaint.pdf` | Sample generated complaint |

## 7. Project structure

```
nyayasetu/
  app.py                     Streamlit UI (7 pages)
  config.py                  settings + env vars
  requirements.txt  .env.example  README.md  EVALUATION_REPORT.md
  core/  intake.py  case_builder.py  rights_analyzer.py  legal_retrieval.py  legal_validation.py
         complaint_generator.py  action_planner.py  llm_provider.py  pipeline.py
  data/legal_sources.json    verified knowledge base
  utils/ pdf_generator.py  language.py
  tests/ test_cases.json  run_tests.py  test_llm_provider.py  test_app_journey.py
  outputs/raw_outputs/  outputs/generated_complaints/
  assets/fonts/              Noto fonts (OFL) + merged font for bilingual PDFs
  docs/                      solution PDF, sample complaint PDF, build script
  .streamlit/config.toml     theme; usage statistics disabled
```

## 8. Privacy

* Case data lives only in the Streamlit session (`st.session_state`); the app writes nothing to disk and keeps no conversation logs. "Clear my case" wipes it.
* Downloads are generated in memory.
* NyayaSetu never asks for Aadhaar, PAN, card numbers, bank passwords or OTPs; if typed, they are masked before storage (checksum-validated Aadhaar/card detection to avoid masking order IDs).
* Streamlit usage statistics are disabled in `.streamlit/config.toml`.
* In live-LLM mode the case facts are sent to the chosen provider; identity numbers are already masked.

## 9. Known limitations

* Scope: online consumer purchases only. Not banking, insurance, real estate, medical, employment, criminal fraud.
* Extraction is rule-based in demo mode: unusual phrasing, typos, Hinglish and long stories can be misread; the user must check the case file. Platforms not in the known list are found only through the follow-up question.
* The KB is small (30 entries), last checked on 8 Nov 2026. The E-Commerce (Amendment) Rules 2026 take effect on 1 Jan 2027 and may change rule text/numbering; the RBI Ombudsman scheme and the CCPA advertising guidelines were verified only from secondary/press sources and are shown as notices.
* The refund claimed is a single total: no per-item breakdown, and for a partial refund the drafts do not say whether goods will be returned.
* Retrieval for the question box is BM25 + a few intent rules: 13/15 probe questions get the best source first, 15/15 in the top 3.
* Drafts quote the user's words; they cannot check truthfulness. Commission draft is a preparation aid, not a filing-ready pleading (affidavit, addresses, format must be completed on e-Jagriti).
* No live LLM call has been made (no API key was available); run `python -m core.llm_provider` with a key to test one. Voice input, document upload/OCR and other Indian languages are not implemented.
* Not deployed: run locally (or deploy to Streamlit Community Cloud by pointing it at `app.py` in a GitHub repo).
